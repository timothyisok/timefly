# -*- coding: utf-8 -*-
import xbmc, xbmcgui, xbmcplugin, xbmcaddon
import sys, os, re, json, urllib.request, urllib.parse
from bs4 import BeautifulSoup

# 常数
__addonname__ = '射手网(伪)字幕插件'
__addonid__   = 'service.subtitles.assrt-net'
__addon__     = xbmcaddon.Addon(id=__addonid__)

# 函数
def getHttpData(url):
	request = urllib.request.Request(url)
	request.add_header('User-Agent', 'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0)')

	maxtimes = 10
	for t in range(maxtimes):
		try:
			response = urllib.request.urlopen(request)
			http_data = response.read()
			break
		except Exception as e:
			if '11004' in str(e):
				if t<maxtimes-1: continue
				else: xbmcgui.Dialog().ok(__addonname__, '网络错误 %s %d次' % (str(e), maxtimes))
			else: xbmcgui.Dialog().ok(__addonname__, '网络错误 %s' % str(e))
			return

	if response.headers.get('content-encoding', None) == 'gzip':
		import zlib
		http_data = zlib.decompress(http_data, zlib.MAX_WBITS|32)

	response.close()
	return http_data

def createUrl(urlInfo):
	url = '%s?' % addon_url
	for key, value in urlInfo.items():
		url += '%s=%s&' % (key, urllib.parse.quote(value))
	url = url[:-1]
	return url

def Search():
	searchstring = params.get('searchstring')
	if searchstring: title = searchstring # 手动下载字幕
	else:
		tvshowtitle = xbmc.getInfoLabel('VideoPlayer.TVshowtitle')
		if tvshowtitle: # 剧集
			season = xbmc.getInfoLabel('VideoPlayer.Season')
			episode = xbmc.getInfoLabel('VideoPlayer.Episode')
			title = '%s.S%.2dE%.2d' % (tvshowtitle, int(season), int(episode))

		else: # 电影或文件
			title = xbmc.getInfoLabel('VideoPlayer.Title')
			basename = os.path.basename(urllib.parse.unquote(xbmc.Player().getPlayingFile()))
			if title == basename: title = os.path.splitext(basename)[0]

		# 标题加上年份
		year = xbmc.getInfoLabel('VideoPlayer.year')
		if year: title += ' (%s)' % year

	order_list = {'默认': '', '评分': 'rank', '相关度': 'relevance'}
	sub_order = __addon__.getSetting('suborder')

	url = 'https://assrt.net/sub/?searchword=%s&sort=%s&no_redir=1' % (urllib.parse.quote(title), order_list[sub_order])
	http_data = getHttpData(url)
	if not http_data: return

	soup = BeautifulSoup(http_data, 'html.parser')
	sub_title_DIVs = soup.find_all('div', class_='sublist_box_title')
	for sub_title_DIV in sub_title_DIVs:
		intro_title_A = sub_title_DIV.find('a', class_='introtitle')
		label2 = intro_title_A['title']
		sub_url = 'https://assrt.net%s' % intro_title_A['href']

		sub_meta_DIV = sub_title_DIV.find_next_sibling('div', id='sublist_div')
		sub_lang_SPAN = sub_meta_DIV.find('span', text=re.compile('语言：'))
		if sub_lang_SPAN: label1 = sub_lang_SPAN.text.replace('语言：', '')
		else: label1 = '未知'

		sub_star_IMG = sub_meta_DIV.find('img')
		icon = str(round(float(sub_star_IMG['src'][13:-4])/20))

		item = xbmcgui.ListItem(label1, label2)
		item.setArt({'icon': icon})
		item_url = createUrl({'action': 'download', 'url': sub_url})
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

	xbmcplugin.endOfDirectory(pHandle)

def Download():
	url = params.get('url')
	http_data = getHttpData(url)
	if not http_data: return

	soup = BeautifulSoup(http_data, 'html.parser')
	sub_DIVs = soup.find_all('div', onmouseover='filelist_expand(this)')
	if sub_DIVs:
		sub_list = []
		for sub_DIV in sub_DIVs:
			sub_list.append(sub_DIV['onclick'][10:-2].split('","'))

		select = xbmcgui.Dialog().select('选择字幕', [sub_item[2] for sub_item in sub_list])
		if select == -1: return

		label = sub_list[select][2]
		sub_url = 'http://assrt.net/download/%s/-/%s/%s' % (sub_list[select][0], sub_list[select][1], urllib.parse.quote(sub_list[select][2]))

	else:
		sub_download_DIV = soup.find('div', class_='download')
		sub_filename_DIV = sub_download_DIV.find_next_sibling('div')

		label = sub_filename_DIV.text.replace('文件名：', '')
		sub_url = 'http://assrt.net%s' % sub_download_DIV.a['href']

	item = xbmcgui.ListItem(label)
	item_url = sub_url
	xbmcplugin.addDirectoryItem(pHandle, item_url, item, False)

	xbmcplugin.endOfDirectory(pHandle)

# 主程序
addon_url = sys.argv[0]
pHandle = int(sys.argv[1])
params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
action = params['action']

# 搜索
if action == 'search' or action == 'manualsearch':
	Search()

# 下载
elif action == 'download':
	Download()