# -*- coding: utf-8 -*-
import xbmcgui, xbmcvfs, xbmcplugin, xbmcaddon
import sys, os, json, base64, urllib, urllib.request, urllib.parse
from lib.utils import m3ujson

# 常数
__addonname__ = 'GitTV网络电视'
__addonid__   = 'plugin.video.gittv'
__addon__     = xbmcaddon.Addon(id=__addonid__)

# 函数
def logData(data, file_path=r'C:\Users\Administrator\Desktop\%s.txt' % __addonname__):
	fHandle = open(file_path, 'w')
	fHandle.write(data)
	fHandle.close()

def showStr(str, type='ok'):
	if type == 'ok': xbmcgui.Dialog().ok(__addonname__, str)
	elif type == 'textviewer': xbmcgui.Dialog().textviewer(__addonname__, str)

def getAddonDir():
	addon_dir = xbmcvfs.translatePath(__addon__.getAddonInfo('path'))
	return addon_dir

def getDataDir():
	data_dir = xbmcvfs.translatePath( __addon__.getAddonInfo('profile'))
	if not os.path.exists(data_dir): os.makedirs(data_dir)
	return data_dir

def getImagePath(image_name):
	addon_dir = getAddonDir()
	image_path = os.path.join(addon_dir, 'media', image_name)
	return image_path

def getHttpData(url):
	request = urllib.request.Request(url)
	request.add_header('User-Agent', 'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0)')

	maxtimes = 10
	for t in range(maxtimes):
		try:
			response = urllib.request.urlopen(request)
			http_data = response.read()
			break

		except Exception as e:
			if '11004' in str(e):
				if t<maxtimes-1: continue
				else: xbmcgui.Dialog().ok(__addonname__, '网络错误 %s %s %d次' % ('url', str(e), maxtimes))
			else: xbmcgui.Dialog().ok(__addonname__, '网络错误 %s %s' % ('url', str(e)))
			return

	if response.headers.get('content-encoding', None) == 'gzip':
		import zlib
		http_data = zlib.decompress(http_data, zlib.MAX_WBITS|32)

	response.close()
	return http_data

def checkUrl(url):
	request = urllib.request.Request(url)
	request.add_header('User-Agent', 'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0)')

	try:
		response = urllib.request.urlopen(request, timeout=5)
		code = response.getcode()
		if code != 200:
			xbmcgui.Dialog().ok(__addonname__, '连接失败 %s [%d]' % ('url', code))
			return

	except Exception as e:
		xbmcgui.Dialog().ok(__addonname__, '网络错误 %s %s' % ('url', str(e)))
		return

	response.close()
	return True

def createUrl(url_info):
	url = '%s?' % addon_url
	for key, value in url_info.items():
		url += '%s=%s&' % (key, urllib.parse.quote(value))
	url = url[:-1]
	return url

def saveChannel(channel, file):
	data_dir = getDataDir()
	file_path = os.path.join(data_dir, file)
	if not os.path.exists(file_path):
		fHandle = open(file_path, 'w')
		channels = [channel]

	else:
		try:
			fHandle = open(file_path, 'r+')
			channels = json.load(fHandle)

			if channel in channels: channels.remove(channel)
			channels.insert(0, channel)
			fHandle.seek(0, 0)

		except json.scanner.JSONDecodeError:
			fHandle = open(file_path, 'w')
			channels = [channel]

	json.dump(channels, fHandle, ensure_ascii=False)
	fHandle.close()

def loadChannel(file):
	data_dir = getDataDir()
	file_path = os.path.join(data_dir, file)
	if not os.path.exists(file_path):
		channels = []

	else:
		try:
			fHandle = open(file_path, 'r')
			channels = json.load(fHandle)

		except json.scanner.JSONDecodeError:
			xbmcgui.Dialog().ok(__addonname__, '记录文件为空或格式有误')
			channels = []
			fHandle.close()

	return channels

def removeChannel(index, file):
	data_dir = getDataDir()
	file_path = os.path.join(data_dir, file)
	fHandle = open(file_path, 'r+')
	channels = json.load(fHandle)

	channels.pop(index)
	fHandle.seek(0, 0)
	fHandle.truncate()

	json.dump(channels, fHandle, ensure_ascii=False)
	fHandle.close()

	xbmc.executebuiltin('Container.Refresh')

def showRoot():
	# 显示根目录
	items = [('Git库', 'repo'), ('收藏', 'favorite'), ('历史', 'history')]
	poster = getImagePath('default.png')
	for entry in items:
		item = xbmcgui.ListItem(entry[0])
		item.setArt({'poster': poster})
		item_url = createUrl({'action': entry[1]})
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

	# 设置内容
	xbmcplugin.setContent(pHandle, 'files')
	xbmcplugin.endOfDirectory(pHandle)

def showRepo():
	url = __addon__.getSetting('configurl')
	http_data = getHttpData(url)
	if not http_data: return

	# 显示Git库
	try:
		repos = json.loads(http_data)
	except json.scanner.JSONDecodeError:
		xbmcgui.Dialog().ok(__addonname__, '配置文件格式有误')
		return

	poster = getImagePath('default.png')
	show_private = __addon__.getSetting('showprivate')
	for entry in repos:
		if entry['visibility'] == 'private':
			if show_private == 'false': continue
			label = '[COLOR yellow]%s/%s/%s[/COLOR]' % (entry['login'], entry['name'], entry['path'])
		else:
			label = '%s/%s/%s' % (entry['login'], entry['name'], entry['path'])

		repo_url = 'https://api.github.com/repos/%s/%s/contents/%s' % (entry['login'], entry['name'], entry['path'])

		path = entry['path']
		keep = entry['keep']
		hide_source = 'false'
		if path in keep: hide_source = 'true'

		item = xbmcgui.ListItem(label)
		item.setArt({'poster': poster})
		item_url = createUrl({'action': 'list', 'url': repo_url, 'path': path, 'keep': json.dumps(keep), 'hide_source': hide_source})
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

	# 设置内容
	xbmcplugin.setContent(pHandle, 'files')
	xbmcplugin.setPluginCategory(pHandle, 'Git库')
	xbmcplugin.endOfDirectory(pHandle)

def showList():
	url = params.get('url')
	http_data = getHttpData(url)
	if not http_data: return

	keep = json.loads(params.get('keep'))

	# 显示列表
	path_list = json.loads(http_data)
	poster = getImagePath('default.png')
	for entry in path_list:
		if entry['type'] == 'dir':
			label = entry['name']
			path_url = entry['url']

			path = params.get('path')
			if not path: path = label
			else: path += '/%s' % label

			hide_source = params.get('hide_source')
			if path in keep: hide_source = 'true'

			item = xbmcgui.ListItem(label)
			item.setArt({'poster': poster})
			item_url = createUrl({'action': 'list', 'url': path_url, 'path': path, 'keep': json.dumps(keep), 'hide_source': hide_source, 'cate': label})
			xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

	for entry in path_list:
		if entry['type'] == 'file' and (entry['name'].endswith('.m3u') or entry['name'].endswith('.m3u8')):
			label = entry['name']
			path_url = entry['url']

			hide_source = params.get('hide_source')

			item = xbmcgui.ListItem(label)
			item.setArt({'poster': poster})
			item_url = createUrl({'action': 'channel', 'cate': label, 'url': path_url, 'hide_source': hide_source, 'cate': label})
			xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

	# 设置内容
	cate = params.get('cate')
	if not cate: cate = '列表'

	xbmcplugin.setContent(pHandle, 'files')
	xbmcplugin.setPluginCategory(pHandle, cate)
	xbmcplugin.endOfDirectory(pHandle)

def showChannel():
	url = params.get('url')
	http_data = getHttpData(url)
	if not http_data: return

	hide_source = params.get('hide_source')

	# 显示频道
	m3u_info = json.loads(http_data)
	m3u_data = base64.b64decode(m3u_info['content']).decode('utf-8')
	channels = m3ujson.load(m3u_data)
	for entry in channels:
		video_url = entry['chn_url']
		if not video_url: continue

		label = entry['chn_name']
		if not label: label = '未知'

		poster = entry['tvg_logo']
		if not poster: poster = 'https://'

		group_title = entry['group_title']
		if not group_title: group_title = '未知'

		source = urllib.parse.urlparse(video_url).netloc
		if hide_source == 'true': source = '未知'
		
		info_labels = {}
		info_labels['plot'] = '[B]分组：[/B]%s\n[B]来源：[/B]%s' % (group_title, source)

		item = xbmcgui.ListItem(label)
		item.setArt({'poster': poster})
		item.setInfo('video', info_labels)
		item.setProperty('IsPlayable', 'true')
		item.addContextMenuItems([('收藏频道', 'RunPlugin(%s)' % createUrl({'action': 'add', 'channel': json.dumps({'label': label, 'poster': poster, 'info_labels': json.dumps(info_labels), 'url': video_url}), 'file': 'favorite.log'}))])
		item_url = createUrl({'action': 'play', 'label': label, 'poster': poster, 'info_labels': json.dumps(info_labels), 'url': video_url})
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, False)

	# 设置内容
	cate = params.get('cate')
	if not cate: cate = '频道'

	xbmcplugin.setContent(pHandle, 'videos')
	xbmcplugin.setPluginCategory(pHandle, cate)
	xbmcplugin.endOfDirectory(pHandle)

def showFavorite():
	# 显示收藏
	channels = loadChannel('favorite.log')
	for i, entry in enumerate(channels):
		video_url = entry.get('url')
		if not video_url: continue

		label = entry.get('label')
		if not label: label = '未知'

		poster = entry.get('poster')
		if not poster: poster = 'https://'

		info_data = entry.get('info_labels')
		if not info_data:
			info_labels = {}
			info_labels['plot'] = '[B]分组：[/B]%s\n[B]来源：[/B]%s' % ('未知', urllib.parse.urlparse(video_url).netloc)

		else:
			try:
				info_labels = json.loads(info_data)
			except json.scanner.JSONDecodeError:
				info_labels = {}
				info_labels['plot'] = '[B]分组：[/B]%s\n[B]来源：[/B]%s' % ('未知', urllib.parse.urlparse(video_url).netloc)

		item = xbmcgui.ListItem(label)
		item.setArt({'poster': poster})
		item.setInfo('video', info_labels)
		item.setProperty('IsPlayable', 'true')
		item.addContextMenuItems([('删除频道', 'RunPlugin(%s)' % createUrl({'action': 'delete', 'index': str(i), 'file': 'favorite.log'}))])
		item_url = createUrl({'action': 'play', 'label': label, 'poster': poster, 'info_labels': json.dumps(info_labels), 'url': video_url})
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, False)

	# 设置内容
	xbmcplugin.setContent(pHandle, 'videos')
	xbmcplugin.setPluginCategory(pHandle, '收藏')
	xbmcplugin.endOfDirectory(pHandle)

def showHistory():
	# 显示历史
	channels = loadChannel('history.log')
	for i, entry in enumerate(channels):
		video_url = entry.get('url')
		if not video_url: continue

		label = entry.get('label')
		if not label: label = '未知'

		poster = entry.get('poster')
		if not poster: poster = 'https://'

		info_data = entry.get('info_labels')
		if not info_data:
			info_labels = {}
			info_labels['plot'] = '[B]分组：[/B]%s\n[B]来源：[/B]%s' % ('未知', urllib.parse.urlparse(video_url).netloc)

		else:
			try:
				info_labels = json.loads(info_data)
			except json.scanner.JSONDecodeError:
				info_labels = {}
				info_labels['plot'] = '[B]分组：[/B]%s\n[B]来源：[/B]%s' % ('未知', urllib.parse.urlparse(video_url).netloc)

		item = xbmcgui.ListItem(label)
		item.setArt({'poster': poster})
		item.setInfo('video', info_labels)
		item.setProperty('IsPlayable', 'true')
		item.addContextMenuItems([('删除频道', 'RunPlugin(%s)' % createUrl({'action': 'delete', 'index': str(i), 'file': 'history.log'}))])
		item_url = createUrl({'action': 'play', 'label': label, 'poster': poster, 'info_labels': json.dumps(info_labels), 'url': video_url})
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, False)

	# 设置内容
	xbmcplugin.setContent(pHandle, 'videos')
	xbmcplugin.setPluginCategory(pHandle, '历史')
	xbmcplugin.endOfDirectory(pHandle)

def playVideo():
	label = params.get('label')
	poster = params.get('poster')
	info_labels = json.loads(params.get('info_labels'))
	url = params.get('url')

	pDialog = xbmcgui.DialogProgress()
	pDialog.create(__addonname__)

	# 检测视频
	pDialog.update(50, '正在检测信号源 [%s] ，请稍等' % label)
	if url.startswith('http'):
		if not checkUrl(url): return

	pDialog.update(100, '信号源 [%s] 检测通过，准备播放' % label)
	pDialog.close()

	# 播放视频
	item = xbmcgui.ListItem(label, path=url)
	item.setArt({'poster': poster})
	item.setInfo('video', info_labels)
	xbmcplugin.setResolvedUrl(pHandle, True, item)

	# 保存历史
	saveChannel({'label': label, 'poster': poster, 'info_labels': json.dumps(info_labels), 'url': url}, 'history.log')

def addChannel():
	channel = json.loads(params.get('channel'))
	file = params.get('file')
	saveChannel(channel, file)

def deleteChannel():
	index = int(params.get('index'))
	file = params.get('file')
	removeChannel(index, file)

# 主程序
addon_url = sys.argv[0]
pHandle = int(sys.argv[1])
params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
action = params.get('action')

# 根目录
if action == None:
	showRoot()

# Git库
elif action == 'repo':
	showRepo()

# 列表
elif action == 'list':
	showList()

# 频道
elif action == 'channel':
	showChannel()

# 收藏
elif action == 'favorite':
	showFavorite()

# 历史
elif action == 'history':
	showHistory()

# 播放
elif action == 'play':
	playVideo()

# 添加频道
elif action == 'add':
	addChannel()

# 删除频道
elif action == 'delete':
	deleteChannel()